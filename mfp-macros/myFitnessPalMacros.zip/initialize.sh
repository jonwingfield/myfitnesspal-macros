#!/bin/bash

mkdir packages
pip3 install -r requirements.txt  -t packages
